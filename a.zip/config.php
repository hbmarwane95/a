<?php

$kadal = [

	'kadal_mode' 				=> 'to',							# bcc / to (Yahoo = to , Hotmail = Bcc)
    'kadal_timezone' 			=> 'Asia/Beijing',					# Default Timezone
	'kadal_charset' 			=> 'UTF-8', 						# UTF-8 support bahasa ALIEN
	'kadal_encoding' 			=> 'base64', 				# Transfer Encoding
    'kadal_max' 				=> 1,  							# Max List / Send
	'kadal_priority'            => '1',                      # 1=High , 3=Normal , 5=Low
    'kadal_remove_duplicate' 	=> false,							# Remove Duplicate
	'kadal_remove_send' 		=> false, 							# Remove Email From List After Send
    'kadal_to' 					=> randomEmail(), 					# Ubah ini kalo junk, Misal : toemail@apple.com 
	'kadal_to1'                 => randomEmail(),                # To email nya yang ke 2
	'kadal_to2'                 => randomEmail(),               # To email nya yang ke 3
    'kadal_handle' 				=> '', 	# Pantau inbox tiap send (BCC only) Kosongin kalo males mantau
    'kadal_attach' 				=> 'attachment.pdf',						    # Attachment Example : Invoice.pdf
	'kadal_attach1'             => 'attachment1.pdf',                           # Attachment 2
	'kadal_attach2'             => 'attachment2.pdf',                           # Attachment 3
	'kadal_attachrename'        => '',    # Rename attachment jadi custom (attach ke 1)
	'kadal_attachrename1'       => '',    # Rename attachment jadi custom (attach ke 2)
	'kadal_attachrename2'       => '',    # Rename attachment jadi custom (attach ke 3)
    'kadal_delay' 				=> 1,								# Delay / Send
    'kadal_dir_file' 			=> 'files/',						# Default do not change

];

// List you want to use
$list_enter = [

    'list_used'                 => 'list.txt',
	'list_dir_file' 			=> 'files/',						# Default do not change

];

// Change your letter
$letter_list = [

    'change_letter'               => 'lette1321r.html',
	'letter_dir_file' 			  => 'files/',						# Default do not change
	
];

// Subject List (sangat ngaruh ke inbox)
$subject_list = [
	'Un service exclusif',
];

// From Name List (Lumayan ngaruh ke inbox)
$fname_list = [
	'S',
];

// From Mail List (Gak Terlalu ngaruh ke inbox)
$fmail_list = [
	'socia201731616@social.helwan.edu.eg',
];

// Shortlink List (sangat sangat ngaruh ke inbox hotmel)
$shortlink_list = [
	'https://google.co.uk/?-p##randomstring##',
];

// Custom Header List (sangat ngaruh ke inbox)
$custom_header = [
	//'Header|Value',
	'X-MAIL-REQUESTED-TIME|'.time(),
	'X-AccountID|992',
	'X-DkimDomain|yourmtgquotes.com',
	'X-DkimSelector|default',
	'x-no-cors|https://sendgrid.com/docs/Classroom/Basics/API/cors.html',
	'X-Feedback-ID|:8594810:992:' .randomNum(3),
	'X-rpcampaign|mpost_8594810_992_' .randomNum(3),
	'X-CFilter-Eagan|'.strtoupper(randomStr(5)),
	'X-Mimecast-Originator|https://www.dailymail.co.uk',
	'X-CSA-Complaints|whitelist-complaints@eco.de',
];