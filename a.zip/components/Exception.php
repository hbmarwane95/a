<?php
/*
Original : PHPMailer
Edited By : BIT-ADMIN
*/
namespace Sender\KADAL;

class Exception extends \Exception
{
    public function errorMessage()
    {
        return '<strong>' . htmlspecialchars($this->getMessage()) . "</strong><br />\n";
    }
	
}
