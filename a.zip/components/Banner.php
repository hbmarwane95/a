 <?php
 // EDITED BY : BIT-ADMIN
 print "\e[91m -.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.\e[0m" . PHP_EOL;
 print "\e[96m                _                                                             \e[0m" . PHP_EOL;
 print "\e[91m  ___          (_)    ___________                                             \e[0m" . PHP_EOL;
 print "\e[92m |    \         __   |____   ____|   ---------------------------------------  \e[0m" . PHP_EOL;
 print "\e[93m |  O  \       |  |      |  |       | => BCC Sender                         | \e[0m" . PHP_EOL;
 print "\e[94m | ___ /  ___  |  |      |  |       | => Secure Sender (For legal user)     | \e[0m" . PHP_EOL;
 print "\e[95m |     \ (___) |  |      |  |       | => Easy To Use                        | \e[0m" . PHP_EOL;
 print "\e[34m |  O  /       |  |   _  |  |       | => Contact Admin If You Have Question | \e[0m" . PHP_EOL;
 print "\e[96m |___ /        |__|  (_) |__|        ---------------------------------------  \e[0m" . PHP_EOL;
 print " " . PHP_EOL;
 print " \e[91m-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.\e[0m" . PHP_EOL;
  ?>