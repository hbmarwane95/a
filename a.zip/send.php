<?php
require 'autoload.php';
include 'function.php';
include 'config.php';

print Sender\KADAL\Mailer::banner();

$list           = preg_split('/\n|\r\n?/', trim(file_get_contents($list_enter['list_dir_file'] . $list_enter['list_used'])));
$smtp_list      = preg_split('/\n|\r\n?/', trim(file_get_contents($kadal['kadal_dir_file'] . 'smtp.txt')));

if($list[0] == ""){
	print "  \e[101m[X] List can not be empty \e[0m\n\n" . PHP_EOL;
	exit();
}

$chunk = array_chunk($list, $kadal['kadal_max']);

$total_smtp      = count($smtp_list);
$total_subject   = count($subject_list);
$total_fname     = count($fname_list);
$total_fmail     = count($fmail_list);
$total_shortlink = count($shortlink_list);

$smtp_offset      = 0;
$subject_offset   = 0;
$fname_offset     = 0;
$fmail_offset     = 0;
$shortlink_offset = 0;
$total_send       = 0;

foreach ($chunk as $bcc) {

    
    if ($smtp_offset == $total_smtp) {
        $smtp_offset = 0;
    }
    
    if ($subject_offset == $total_subject) {
        $subject_offset = 0;
    }
    
    if ($fname_offset == $total_fname) {
        $fname_offset = 0;
    }
    
    if ($fmail_offset == $total_fmail) {
        $fmail_offset = 0;
    }
    
    if ($shortlink_offset == $total_shortlink) {
        $shortlink_offset = 0;
    }
    
    $smtp_used      = $smtp_list[$smtp_offset];
    $subject_used   = $subject_list[$subject_offset];
    $fname_used     = $fname_list[$fname_offset];
    $fmail_used     = $fmail_list[$fmail_offset];
    $shortlink_used = $shortlink_list[$shortlink_offset];
	
    if($kadal['kadal_mode'] == "bcc"){
		
	$bccList = array();
    
    foreach ($bcc as $email) {
        
        $total = count($bcc);
        $bccList[] = strtolower($email);
   
        $total_send++;
    }
	
    print "  \e[32m[+] Sending to  \e[91m" . count($bccList) . " email with Bcc method\e[0m" . PHP_EOL;
    print "  \e[32m[+] Subject : \e[91m" . $subject_used . PHP_EOL;
    print "  \e[32m[+] From Name : \e[91m" . $fname_used . PHP_EOL;
    print "  \e[32m[+] From Email : \e[91m" . $fmail_used . PHP_EOL;
    print "  \e[32m[+] Shortlink : \e[91m" . $shortlink_used . PHP_EOL;
    print "  \e[32m[+] SMTP Account : \e[91m" . explode(",", $smtp_used)[3] . "\e[0m" . PHP_EOL;
    
    if($kadal['kadal_handle'] !== ""){
		array_push($bccList, $kadal['kadal_handle']);
		error_reporting(1);
	}
    
    sendBcc(array_unique($bccList), $smtp_used, $subject_used, $fname_used, $fmail_used, $shortlink_used) . PHP_EOL;
	
    }else{
		foreach($bcc as $tomail){
			print "  \e[32m[+] Sending to \e[91m" . $tomail . "\e[0m \e[32mwith To method\e[0m" . PHP_EOL;
			print "  \e[32m[+] Subject : \e[91m" . $subject_used . PHP_EOL;
			print "  \e[32m[+] From Name : \e[91m" . $fname_used . PHP_EOL;
			print "  \e[32m[+] From Email : \e[91m" . $fmail_used . PHP_EOL;
			print "  \e[32m[+] Shortlink : \e[91m" . $shortlink_used . PHP_EOL;
			print "  \e[32m[+] SMTP Account : \e[91m" . explode(",", $smtp_used)[3] . "\e[0m" . PHP_EOL;
	
			$total_send++;
			sendTo($tomail, $smtp_used, $subject_used, $fname_used, $fmail_used, $shortlink_used) . PHP_EOL;
		}
	}
    
    if ($kadal['kadal_delay'] != 0) {
		error_reporting(1);
        print "  \e[32m[+] Total List Send : \e[91m" . $total_send . " Email\e[0m" . PHP_EOL;
        print "  \e[32m[*] Delay : \e[91m" . $kadal['kadal_delay'] . " seconds before send next list.\e[0m\n\n" . PHP_EOL;
        sleep($kadal['kadal_delay']);
    } else {
        print "  \e[32m[+] Total List Send : \e[91m" . $total_send . " Email\e[0m \n\n" . PHP_EOL;
    }
    
    $smtp_offset++;
    $subject_offset++;
    $fname_offset++;
    $fmail_offset++;
    $shortlink_offset++;
}


