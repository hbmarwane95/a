<?php 

foreach (glob("components/*.php") as $filename)
{
    include $filename;
}
