<?php 
use Sender\KADAL\Mailer;
use Sender\KADAL\Exception;

function randomin($data)
{

    $tags = array(
		"##randomemail##",
		"##randomstring##",
		"##randomstring1##",
		"##randomstring2##",
		"##randomstring3##",
		"##randomstring4##",
		"##randomstringlower##",
		"##randomstringupper##",
		"##randomnumber##",
		"##bitku##",
        "##date##",
		"##randomip##",
		"##randomos##",
		"##randomdevice##",
    );
	
    $rep  = array(
		randomEmail(),
		randomStr(10),
		randomStr1(10),
		randomStr2(10),
		randomStr3(10),
		randomStr4(10),
		strtolower(randomStr(20)),
		strtoupper(randomStr(20)),
		randomNum(10),
		bitku(),
        date('r'),
		randIP(),
		randomOS(),
		randomDevice()
    );
	
    return str_replace($tags, $rep, $data);
}

function randomNum($length)
    {
        $result = '';
        
        for ($i = 0; $i < $length; $i++) {
            $result .= mt_rand(0, 9);
        }
        
        return $result;
    }
	
function randomStr($length = 10)
    {
        $characters       = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $charactersLength = strlen($characters);
        $randomString     = '';
        for ($i = 0; $i < $length; $i++) {
            $randomString .= $characters[rand(0, $charactersLength - 1)];
        }
        return $randomString;
}

function randomStr1($length = 10)
    {
        $characters       = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $charactersLength = strlen($characters);
        $randomString     = '';
        for ($i = 0; $i < $length; $i++) {
            $randomString .= $characters[rand(0, $charactersLength - 1)];
        }
        return $randomString;
}

function randomStr2($length = 10)
    {
        $characters       = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $charactersLength = strlen($characters);
        $randomString     = '';
        for ($i = 0; $i < $length; $i++) {
            $randomString .= $characters[rand(0, $charactersLength - 1)];
        }
        return $randomString;
}

function randomStr3($length = 10)
    {
        $characters       = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $charactersLength = strlen($characters);
        $randomString     = '';
        for ($i = 0; $i < $length; $i++) {
            $randomString .= $characters[rand(0, $charactersLength - 1)];
        }
        return $randomString;
}

function randomStr4($length = 10)
    {
        $characters       = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $charactersLength = strlen($characters);
        $randomString     = '';
        for ($i = 0; $i < $length; $i++) {
            $randomString .= $characters[rand(0, $charactersLength - 1)];
        }
        return $randomString;
}

function randomEmail()
    {
        $tld = array(
            "com",
            "net",
            "gov",
            "org",
            "edu",
            "biz",
            "info",
			"us",
			"ca",
			"fr",
			"de",
			"au",
        );
        return strtolower (randomStr($length = 15)) . "@" . strtolower (randomStr($length = 8)) . "." . strtolower (randomStr($length = 15)) . "." . $tld[array_rand($tld)];
}

function bitku()
    {
		$characters       = 'office365';
		$charactersLength = $characters;
		$bitku     = $characters;
		for ($i = 0; $i < $characters; $i++) {
            $bitku .= $characters;
        }
        return $bitku;
}

function randIP()
    {
        $result = mt_rand(0, 255) . '.' .mt_rand(0, 255) . '.' .mt_rand(0, 255) . '.' .mt_rand(0, 255);
        
        for ($i = 0; $i ; $i++) {
            $result .= mt_rand(0, 255);
        }
        
        return $result;
	}
	
function randomOS()
    {
        $oslist = array(
            "Windows 7",
            "Windows Vista",
            "Windows XP",
            "Windows 8",
            "Windows 10",
			"Mac OS X",
			"Apple iOS",
			"Cent OS",
			"Linux",
			"Ubuntu",
			"Android",
			"Windows Phone",
        );
        return $oslist[array_rand($oslist)];
	}

function randomDevice()
    {
        $devicelist = array(
            "iPhone 6",
            "iPhone 6s",
            "iPhone 6s+",
            "iPhone 7",
            "iPhone 7s",
			"iPhone 7s+",
			"iPhone 8",
			"iPhone 8s",
			"iPhone 8s+",
			"iPhone X",
			"iPhone XS",
			"iPhone XS Max",
			"iPhone 11",
			"iPhone 11 Pro",
			"iPhone 11 Pro Max",
			"iPhone XR",
			"iPad",
			"iPad 2",
			"iPad 3",
			"iPad 4",
			"iPad 9.7",
			"iPad 10.2",
			"iPad Air",
			"iPad Air 2",
			"iPad Mini",
			"iPad Mini 3",
			"iPad Mini 4",
			"iPad Pro",
			"Samsung Galaxy Xcover Pro",
			"Samsung Galaxy Note10 Lite",
			"Samsung Galaxy S10 Lite",
			"Samsung Galaxy A01",
			"Samsung Galaxy A71",
			"Samsung Galaxy A51",
			"Samsung Galaxy Xcover Field Pro",
			"Samsung Galaxy A70s",
			"Samsung Galaxy A20s",
			"Samsung Galaxy M30s",
			"Samsung Galaxy M10s",
			"Samsung Galaxy Fold 5G",
			"Samsung Galaxy Fold",
			"Samsung Galaxy Tab Active Pro",
			"Samsung Galaxy A90 5G",
			"Samsung Galaxy A30s",
			"Samsung Galaxy A50s",
			"Samsung Galaxy Note10+ 5G",
			"Samsung Galaxy Note10+",
			"Samsung Galaxy Note10",
			"Samsung Galaxy Tab S6",
			"Samsung Galaxy Note9",
			"Samsung Galaxy S9",
			"Samsung Galaxy S8+",
			"Samsung Galaxy A8",
			"Samsung Galaxy S9+",
			"Motorolla Phone",
			"Xiaomi Phone",
			"Nokia Phone",
			"Acer Phone",
			"Lenovo Phone",
			"Sharp Phone",
			"LG Phone",
			"Sony Phone",
			"Google Phone",
			"Asus Phone",
			"Asus Republic Of Gamers",
			"Huawei Phone",
			"Microsoft Phone",
			"Vivo Phone",
			"Oppo Phone",
			"Meizu Phone",
			"Realme Phone",
			"Vodafone Phone",
			"Blackberry Phone",
			
        );
        return $devicelist[array_rand($devicelist)];
	}
	
function sendBcc($bccList = array(), $smtp_account, $subject, $fname, $fmail, $short)
{
	
	global $kadal, $list, $letter_list, $custom_header;;
	
    $mail = new Mailer(true);
    
    try {
        $smtp = explode("," , $smtp_account);
		$letter = randomin(str_replace(array('##shortlink##'),array($short), file_get_contents($letter_list['letter_dir_file'] . $letter_list['change_letter'])));
		$domainSMTP = explode("@", $smtp[3])[1];
	
        $mail->isSMTP();
        $mail->Host       = $smtp[0];
        $mail->SMTPAuth   = true;
        $mail->Username   = $smtp[3];
        $mail->Password   = $smtp[4];
        $mail->SMTPSecure = $smtp[2];
        $mail->Port       = $smtp[1];
        $mail->XMailer    = '';
		$mail->CharSet = $kadal['kadal_charset'];
        $mail->Encoding   = $kadal['kadal_encoding'];
		$mail->Priority = $kadal['kadal_priority'];
        
        $mail->setFrom(randomin(str_replace("##domainsmtp##", $domainSMTP, $fmail)), randomin($fname));
        
        $mail->addAddress($kadal['kadal_to']);
		$mail->addAddress($kadal['kadal_to1']);
        $mail->addAddress($kadal['kadal_to2']);
		
        
		foreach ($bccList as $email) {
			
			$mail->addBcc($email);
			
			if($kadal['kadal_remove_send']){
				$list = array_diff($list, array($email));
				file_put_contents($list_enter['list_dir_file'] . 'list_used',implode("\r\n", $list));
			}
			
		}
		
		$bounce = explode("@", $bccList[0]);
		
		if($kadal['kadal_attach'] != ""){
			$mail->addAttachment($kadal['kadal_dir_file'] . $kadal['kadal_attach'], randomin($kadal['kadal_attachrename']));
			$mail->addAttachment($kadal['kadal_dir_file'] . $kadal['kadal_attach1'], randomin($kadal['kadal_attachrename1']));
			$mail->addAttachment($kadal['kadal_dir_file'] . $kadal['kadal_attach1'], randomin($kadal['kadal_attachrename2']));
        }

		foreach($custom_header as $cheader){
			$chead = explode("|", $cheader);
			$mail->addCustomHeader($chead[0], $chead[1]);
		}
		
        $mail->isHTML(true);
        $mail->Subject = randomin($subject);
        $mail->Body    = $letter;
        
        $result = $mail->send();
		
		echo "  \e[32m[+] Send Status :\e[0m \e[102mSuccess\e[0m" . PHP_EOL;
		$mail->ClearAllRecipients();
        
    }catch (Exception $e) {
		echo "  \e[32m[X] Send Status :\e[0m \e[101m".$mail->ErrorInfo." \e[0m" . PHP_EOL;
    }
    
}


function sendTo($receiver, $smtp_account, $subject, $fname, $fmail, $short)
{
	
	global $kadal, $list, $letter_list, $custom_header;
	
    $mail = new Mailer(true);
    
    try {
        $smtp = explode("," , $smtp_account);
		$letter = randomin(str_replace(array('##shortlink##', '##email##'),array($short, $receiver), file_get_contents($letter_list['letter_dir_file'] . $letter_list['change_letter'])));
		$domainSMTP = explode("@", $smtp[3])[1];
	
        $mail->isSMTP();
        $mail->Host       = $smtp[0];
        $mail->SMTPAuth   = true;
        $mail->Username   = $smtp[3];
        $mail->Password   = $smtp[4];
        $mail->SMTPOptions = array(
		   'ssl' => array(
					'verify_peer' => false,
					'verify_peer_name' => false,
					'allow_self_signed' => true
				)
			);
        $mail->Port       = $smtp[1];
        $mail->XMailer    = '';
		$mail->CharSet = $kadal['kadal_charset'];
        $mail->Encoding   = $kadal['kadal_encoding'];
		$mail->Priority = $kadal['kadal_priority'];
        
        $mail->setFrom(randomin(str_replace("##domainsmtp##", $domainSMTP, $fmail)), randomin($fname));
        
        $mail->addAddress($receiver);
		
			
		if($kadal['kadal_remove_send']){
			$list = array_diff($list, array($email));
			file_put_contents($list_enter['list_dir_file'] . 'list_used',implode("\r\n", $list));
		}

		
		$bounce = explode("@", $receiver);
		
		if($kadal['kadal_attach'] != ""){
			$mail->addAttachment($kadal['kadal_dir_file'] . $kadal['kadal_attach'], randomin($kadal['kadal_attachrename']));
			$mail->addAttachment($kadal['kadal_dir_file'] . $kadal['kadal_attach1'], randomin($kadal['kadal_attachrename1']));
			$mail->addAttachment($kadal['kadal_dir_file'] . $kadal['kadal_attach2'], randomin($kadal['kadal_attachrename2']));
        }
		
        foreach($custom_header as $cheader){
			$chead = explode("|", $cheader);
			$mail->addCustomHeader($chead[0], $chead[1]);
		}
		
        
		$mail->isHTML(true);
        $mail->Subject = randomin($subject);
        $mail->Body    = $letter;
        
        $result = $mail->send();
		
		echo "  \e[32m[+] Send Status :\e[0m \e[102mSuccess\e[0m" . PHP_EOL;
		$mail->ClearAllRecipients();
        
    }catch (Exception $e) {
		echo "  \e[32m[X] Send Status :\e[0m \e[101m".$mail->ErrorInfo." \e[0m" . PHP_EOL;
    }
    
}

{
}